--创建表ACCESS_LOG
create table ACCESS_LOG
(
  id                NUMBER(18) not null,
  request_url  VARCHAR2(256),
  access_ip     VARCHAR2(256),
  access_start_time   VARCHAR2(256),
  access_end_time  VARCHAR2(256),
  request_param   clob,
  response_param  clob,
  session_id VARCHAR2(256)
)
tablespace CUST1DATA
  pctfree 10
  initrans 1
  maxtrans 255;
  
create sequence SEQ_ACCESS_LOG 
minvalue 1 
maxvalue 999999999999999999999999999 
start with 1 
increment by 1 
nocache;
-- Create/Recreate primary, unique and foreign key constraints 
alter table ACCESS_LOG
  add primary key (ID)
  using index 
  tablespace CUST1DATA
  pctfree 10
  initrans 2
  maxtrans 255;


--创建表ACCESS_LOG_HISTORY  
create table ACCESS_LOG_HISTORY
(
  id                NUMBER(18) not null,
  request_url  VARCHAR2(256),
  access_ip     VARCHAR2(256),
  access_start_time   VARCHAR2(256),
  access_end_time  VARCHAR2(256),
  request_param   clob,
  response_param  clob,
  session_id VARCHAR2(256)
)
tablespace CUST1DATA
  pctfree 10
  initrans 1
  maxtrans 255;
-- Create/Recreate primary, unique and foreign key constraints 
alter table ACCESS_LOG_HISTORY
  add primary key (ID)
  using index 
  tablespace CUST1DATA
  pctfree 10
  initrans 2
  maxtrans 255;
