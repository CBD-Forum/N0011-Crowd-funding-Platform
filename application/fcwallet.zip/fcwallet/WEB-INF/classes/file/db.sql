/*<<<<<<<<<<<<<<<<<<<<<<<<<<<<<指旺币SQL start>>>>>>>>>>>>>>>>>>>>*/
/*
Navicat MySQL Data Transfer

Source Server         : 172.16.10.82
Source Server Version : 50636
Source Host           : 172.16.10.82:3306
Source Database       : zwbapi

Target Server Type    : MYSQL
Target Server Version : 50636
File Encoding         : 65001

Date: 2017-04-20 15:49:44
*/

SET FOREIGN_KEY_CHECKS=0;

-- ----------------------------
-- Table structure for `record`
-- ----------------------------
DROP TABLE IF EXISTS `record`;
CREATE TABLE `record` (
  `id` int(10) NOT NULL,
  `onumber` varchar(100) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `enumber` varchar(100) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `amount` double(10,2) DEFAULT NULL,
  `rem` varchar(100) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `transactiontype` int(2) DEFAULT NULL,
  `time` varchar(30) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `transnum` varchar(300) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;


/*
Navicat MySQL Data Transfer

Source Server         : 172.16.10.82
Source Server Version : 50636
Source Host           : 172.16.10.82:3306
Source Database       : zwbapi

Target Server Type    : MYSQL
Target Server Version : 50636
File Encoding         : 65001

Date: 2017-04-20 15:50:24
*/

SET FOREIGN_KEY_CHECKS=0;

-- ----------------------------
-- Table structure for `user`
-- ----------------------------
DROP TABLE IF EXISTS `user`;
CREATE TABLE `user` (
  `id` int(10) NOT NULL,
  `code` varchar(100) NOT NULL,
  `number` varchar(100) NOT NULL,
  `passwd` varchar(100) NOT NULL,
  `balance` double(10,2) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*<<<<<<<<<<<<<<<<<<<<<<<<<<<<<指旺币SQL end>>>>>>>>>>>>>>>>>>>>*/
