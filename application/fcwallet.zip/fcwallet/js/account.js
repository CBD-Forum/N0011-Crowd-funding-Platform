$(function(){
	var user_session_id = getCookie("user_session_id");
	var user_session_name = getCookie("user_session_name");
	if(user_session_id!=null && user_session_id!=''){
		$(".login").html(user_session_name);
		$("#logout").show();
	}else{
		$(".login").html("登录");
		$("#logout").hide();
	}
	
	var hash = location.hash;
	if(hash=="#addcert"){
		var me = $("#xmgl_dt");
	    me.nextUntil("dt").toggle();
		$("#wdfq_dd").attr({"class":"active"});
		$("#voucher-view").show();
	}
	
	var b = new Base64();
	var orderlistparam = '["query","userOrderList","'+user_session_id+'"]';
	var orderliststr = b.encode(orderlistparam);
	$.ajax({
		type :'get',
		url :url+'?username=sam&orgName=org1&peer=peer1&args='+orderliststr+'&chaincodeVersion=v0',
		data : {
		},
		dataType :'json',
		success : function(obj) {
			if(obj!=null){
				for(var i=0;i<obj.length;i++){
					var id = obj[i].id;
					var amount = obj[i].amount;//总金额
					var current = obj[i].current;//已筹款
					var progress = (current/amount)*100 + '%';//进度
					var investcount = obj[i].investRecords.length;
					var title = obj[i].title;
					var rate = obj[i].rate;//收益率
					var createTime = obj[i].createTime;//创建时间
					var endTime = obj[i].endTime;//结束时间
					var syTime = dumpTime(new Date(createTime),new Date(endTime));//剩余时间
					var status1=obj[i].status;
					var investRecords = obj[i].investRecords;//认筹记录集合
					var tradeCertificate = obj[i].tradeCertificate.trim();//img上传的hash值
					if(tradeCertificate != "" && tradeCertificate!=null){
						$("#scpzSubmitbtn").attr("disabled","disabled");
						$("#fileInput").attr("disabled","disabled");
					}
					
					var oper;
					var status;
					if(status1 =="3"){
						status = "已放款";
						oper = "还款";
						progress ="100%"
					}else if(status1 =="5"){
						status = "完成";
						oper = "结束";
						progress ="100%"
					}else{
						status = "不可结算";
						oper = "提交审核";
					}
					//我的发起
					$("#fqlist").append("<div class='addtime'>添加时间："+createTime+"<div class='delete'><img src='images/delete.png' alt=''></div></div><div class='mine-body'><div class='mine-name'>"+title+"</div><div class='mine-state'>草稿箱</div><div class='mine-process'>目标："+amount+"元<div class='progress'><div class='progress-bar' role='progressbar' aria-valuenow='60' aria-valuemin='0' aria-valuemax='100' style='width: "+progress+";'></div></div><span>"+progress+"</span></div><div class='mine-status'>"+status+"</div><div class='mine-action'><button id='operBtn'>"+oper+"</button><a href='javascript:void(0)'>编辑</a><a href='javascript:void(0)'>预览</a> <div class='voucher'>用款凭证</div></div></div>");
					  // 用款凭证
			        $(".voucher").on("click",function (e) {
			            $("#voucher-view").show();
			        })
			        $("#voucher-close").on("click",function (e) {
			            $("#voucher-view").hide();
			        })
			        $("#add-voucher").on("click",function (e) {
			            $("#voucher-view").hide();
			            $("#add-voucher-view").show();
			        })
			        $("#voucher-cancel").on("click",function (e) {
			            e.preventDefault();
			            $("#add-voucher-view").hide();
			        })
			        
			        
					if(status1 =="5"){
						$("#operBtn").attr("disabled:disabled");
					}
					
					//还款
					$("#operBtn").click(function(){
						var index = layer.load(1, {
				        	shade: [0.4,'#fff'] //0.1透明度的白色背景
			        	});
						var hk_param = '["refund",'+'"'+id+'"]';
					    var hk_str = b.encode(hk_param);
						$.ajax({
							type :'post',
							url :url,
							data : {
								"peers": ["localhost:7051"],
								"chaincodeVersion":"v0",
								"functionName":"invoke",
								"username":"sam",
						        "orgName":"org1",
							    "args":hk_str
							},
							dataType :'json',
							success : function(obj) {
							}
					 	})
					 	setTimeout(function(){
							location.reload();
						},10000)
						
					})
					
					//加载我的发起上传的图片
					$.ajax({
						type :'get',
						url :"accountImg",
						data : {
						},
						dataType :'json',
						success : function(obj) {
							var result = obj.reslut; 
							result = result.substr(1,result.length-2);
							var temp = result.split(",");
							if(temp!=""){
								for(var i=0;i<temp.length;i++){
									var imgHash = temp[i].split("=")[0];
									var imgTemp = temp[i].split("=")[1].split("|");
									var imgDate = imgTemp[0];
									var imgUrl = "http://" + location.host +"/fcwallet/img/"+imgTemp[1];
									var iiname = imgTemp[1].split(".")[0];
									$("#img_div").append("<div class='col-md-4'>"+imgDate+"</br> 图片名字："+imgTemp[1]+"</br><button type='button' class='btn btn-primary' id='jybtn"+iiname+"'>校验</button>&nbsp;<span id='jyjgbtn"+iiname+"'></span></div><div class='col-md-8'><img src='"+imgUrl+"' alt=''></div>");
									if(user_session_name!="admin"){
										$("#jybtn"+iiname).hide();
										$("#jyjgbtn"+iiname).hide();
									}
									//校验图片
									$("#jybtn"+iiname).click(function(){
										$.ajax({
											type :'post',
											url :"validateImg",
											data : {
												"param":imgTemp[1]
											},
											dataType :'text',
											success : function(data) {
												var orderId = window.location.pathname.substr("/fcwallet/order/".length);
											    var param = '["query","order","'+id+'"]';
											    var str = b.encode(param);
												$.ajax({
													type :'get',
													url :url+'?username=sam&orgName=org1&peer=peer1&args='+str+'&chaincodeVersion=v0',
													data : {
													},
													dataType :'json',
													success : function(obj) {
														var tradeCertificate = obj.tradeCertificate.trim();
														if(data==tradeCertificate){
															$("#jyjgbtn"+iiname).html("结果一致！");
														}else{
															$("#jyjgbtn"+iiname).html("结果不一致！");
														}
													}
												})
											}
									 	})
									})
									
									var aa_img = '["uploadTradeCertificate",'+'"'+id+'","'+imgHash+'"]';
								    var str_img = b.encode(aa_img); 
									$.ajax({
										type :'post',
										url :url,
										data : {
											"peers": '["localhost:7051"]',
											"chaincodeVersion":"v0",
											"functionName":"invoke",
											"username":"sam",
									        "orgName":"org1",
										    "args":str_img
										},
										dataType :'text',
										success : function(obj) {
										}
								 	})
								
								}
							}
						}
				 	})
				}
			}
		}
 	})
 	//认筹记录
 	var investlistparam = '["query","investRecord","'+user_session_id+'"]';
	var investliststr = b.encode(investlistparam);
	$.ajax({
		type :'get',
		url :url+'?username=sam&orgName=org1&peer=peer1&args='+investliststr+'&chaincodeVersion=v0',
		data : {
		},
		dataType :'json',
		success : function(obj) {
			for(var j=0;j<obj.length;j++){
				var investId = obj[j].id;//认筹记录id
				var tzrId = obj[j].creatorId;//投资人id
				var username = obj[j].userName;//投资人名称
				var investmount = obj[j].amount;//认筹金额
				var title = obj[j].title;
				var createTime = obj[j].createTime;
				$("#investRecords").append("<tr class='row'><td><div class=''>"+title+"</div></td><td>固定收益</td><td>众筹成功</td><td>"+createTime+"</td><td>"+investmount+"<br />总共："+investmount+"份<br /></td><td>等待回报</td><td>固定收益</td><td><a href='#'>查看合同</a><a href='#'>查看回报详情</a></td></tr>");
			}
		}
	})
	
	//收益记录
 	var investlistparam = '["query","refundRecord","'+user_session_id+'"]';
	var investliststr = b.encode(investlistparam);
	$.ajax({
		type :'get',
		url :url+'?username=sam&orgName=org1&peer=peer1&args='+investliststr+'&chaincodeVersion=v0',
		data : {
		},
		dataType :'json',
		success : function(obj) {
			if(obj == null || obj == ""){
				$("#investRecordBody").append("")
			}else{
				for(var j=0;j<obj.length;j++){
					var id = obj[j].id;//认筹记录id
					var tzrId = obj[j].creatorId;//投资人id
					var username = obj[j].userName;//投资人名称
					var investmount = obj[j].amount;//认筹金额
					var title = obj[j].title;
					var createTime = obj[j].createTime;
					$("#investRecordBody").append("<tr class='row'>" +
							"<th class='col-md-3'>"+createTime+"</th>"+
							"<th class='col-md-32'>"+title+"</th>"+
							"<th class='col-md-3'>"+"固定收益"+"</th>"+
							"<th class='col-md-3'>"+investmount.toFixed(2)+"</th>"+
							"<th class='col-md-3'>"+title+"回款</th>"
					);
				}
			}
		}
	})
 	
	var userlistparam = '["query","userList","fZeF4V4KQzk5qi2yRr79NNoJ0VbIEs52"]';
    var userliststr = b.encode(userlistparam);				
	$.ajax({
		type :'get',
		url :url+'?username=sam&orgName=org1&peer=peer1&args='+userliststr+'&chaincodeVersion=v0',
		data : {
		},
		dataType :'json',
		success : function(data) {
			for(var k=0;k<data.length;k++){
				if(data[k].name==user_session_name){
					var account_ye = data[k].amount;
					$("#account_ye").html("￥"+account_ye.toFixed(2));
					$("#uuuser").html(user_session_name);
				}
			}
		}
	})
					
	
	
	//发起项目
	$("#xmbtn").click(function(){
		var index = layer.load(1, {
        	shade: [0.4,'#fff'] //0.1透明度的白色背景
    	});
		var date = new Date();//获取当前时间  
		date.setDate(date.getDate()+parseInt($("#duration").val()));//设置天数 -1 天  
		var time = date.Format("yyyy-MM-dd hh:mm:ss");  
		var aa = '["createOrder",'+'"'+$("#project-name").val()+'",'+'"'+$("#sum").val()+'",'+'"'+$("#interest-rate").val()/100+'","'+user_session_id+'","'+getNowFormatDate(0)+'","'+time+"\"]";
	    var str = b.encode(aa); 
		$.ajax({
			type :'post',
			url :url,
			data : {
				"peers": '["localhost:7051"]',
				"chaincodeVersion":"v0",
				"functionName":"invoke",
				"username":"sam",
		        "orgName":"org1",
			    "args":str
			},
			dataType :'json',
			success : function(obj) {
				console.info(obj);
			}
	 	})
	 	setTimeout(function(){
			location.href="/fcwallet";
		},10000)
	});
	
		
})

function dumpTime(date1,date2){
    var date3 = date2.getTime() - new Date(date1).getTime();   //时间差的毫秒数        
  
    //计算出相差天数  
    var days=Math.floor(date3/(24*3600*1000))  
  
    //计算出小时数  
  
    var leave1=date3%(24*3600*1000)    //计算天数后剩余的毫秒数  
    var hours=Math.floor(leave1/(3600*1000))  
    //计算相差分钟数  
    var leave2=leave1%(3600*1000)        //计算小时数后剩余的毫秒数  
    var minutes=Math.floor(leave2/(60*1000))  
    //计算相差秒数  
    var leave3=leave2%(60*1000)      //计算分钟数后剩余的毫秒数  
    var seconds=Math.round(leave3/1000)  
    return days+"天 "+hours+"小时 "+minutes+" 分钟"+seconds+" 秒"; 
}

function getNowFormatDate(number) {
    var date = new Date();
    var seperator1 = "-";
    var seperator2 = ":";
    var month = date.getMonth() + 1;
    var strDate = date.getDate()+parseInt(number);
    if (month >= 1 && month <= 9) {
        month = "0" + month;
    }
    if (strDate >= 0 && strDate <= 9) {
        strDate = "0" + strDate;
    }
    var currentdate = date.getFullYear() + seperator1 + month + seperator1 + strDate
            + " " + date.getHours() + seperator2 + date.getMinutes()
            + seperator2 + date.getSeconds();
    return currentdate;
}

Date.prototype.Format = function (fmt) {  
    var o = {  
        "M+": this.getMonth() + 1, //月份   
        "d+": this.getDate(), //日   
        "h+": this.getHours(), //小时   
        "m+": this.getMinutes(), //分   
        "s+": this.getSeconds(), //秒   
        "q+": Math.floor((this.getMonth() + 3) / 3), //季度   
        "S": this.getMilliseconds() //毫秒   
    };  
    if (/(y+)/.test(fmt)) fmt = fmt.replace(RegExp.$1, (this.getFullYear() + "").substr(4 - RegExp.$1.length));  
    for (var k in o)  
    if (new RegExp("(" + k + ")").test(fmt)) fmt = fmt.replace(RegExp.$1, (RegExp.$1.length == 1) ? (o[k]) : (("00" + o[k]).substr(("" + o[k]).length)));  
    return fmt;  
}  

function Base64() {  
	   
    // private property  
    _keyStr = "ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789+/=";  
   
    // public method for encoding  
    this.encode = function (input) {  
        var output = "";  
        var chr1, chr2, chr3, enc1, enc2, enc3, enc4;  
        var i = 0;  
        input = _utf8_encode(input);  
        while (i < input.length) {  
            chr1 = input.charCodeAt(i++);  
            chr2 = input.charCodeAt(i++);  
            chr3 = input.charCodeAt(i++);  
            enc1 = chr1 >> 2;  
            enc2 = ((chr1 & 3) << 4) | (chr2 >> 4);  
            enc3 = ((chr2 & 15) << 2) | (chr3 >> 6);  
            enc4 = chr3 & 63;  
            if (isNaN(chr2)) {  
                enc3 = enc4 = 64;  
            } else if (isNaN(chr3)) {  
                enc4 = 64;  
            }  
            output = output +  
            _keyStr.charAt(enc1) + _keyStr.charAt(enc2) +  
            _keyStr.charAt(enc3) + _keyStr.charAt(enc4);  
        }  
        return output;  
    }  
   
    // public method for decoding  
    this.decode = function (input) {  
        var output = "";  
        var chr1, chr2, chr3;  
        var enc1, enc2, enc3, enc4;  
        var i = 0;  
        input = input.replace(/[^A-Za-z0-9\+\/\=]/g, "");  
        while (i < input.length) {  
            enc1 = _keyStr.indexOf(input.charAt(i++));  
            enc2 = _keyStr.indexOf(input.charAt(i++));  
            enc3 = _keyStr.indexOf(input.charAt(i++));  
            enc4 = _keyStr.indexOf(input.charAt(i++));  
            chr1 = (enc1 << 2) | (enc2 >> 4);  
            chr2 = ((enc2 & 15) << 4) | (enc3 >> 2);  
            chr3 = ((enc3 & 3) << 6) | enc4;  
            output = output + String.fromCharCode(chr1);  
            if (enc3 != 64) {  
                output = output + String.fromCharCode(chr2);  
            }  
            if (enc4 != 64) {  
                output = output + String.fromCharCode(chr3);  
            }  
        }  
        output = _utf8_decode(output);  
        return output;  
    }  
   
    // private method for UTF-8 encoding  
    _utf8_encode = function (string) {  
        string = string.replace(/\r\n/g,"\n");  
        var utftext = "";  
        for (var n = 0; n < string.length; n++) {  
            var c = string.charCodeAt(n);  
            if (c < 128) {  
                utftext += String.fromCharCode(c);  
            } else if((c > 127) && (c < 2048)) {  
                utftext += String.fromCharCode((c >> 6) | 192);  
                utftext += String.fromCharCode((c & 63) | 128);  
            } else {  
                utftext += String.fromCharCode((c >> 12) | 224);  
                utftext += String.fromCharCode(((c >> 6) & 63) | 128);  
                utftext += String.fromCharCode((c & 63) | 128);  
            }  
   
        }  
        return utftext;  
    }  
   
    // private method for UTF-8 decoding  
    _utf8_decode = function (utftext) {  
        var string = "";  
        var i = 0;  
        var c = c1 = c2 = 0;  
        while ( i < utftext.length ) {  
            c = utftext.charCodeAt(i);  
            if (c < 128) {  
                string += String.fromCharCode(c);  
                i++;  
            } else if((c > 191) && (c < 224)) {  
                c2 = utftext.charCodeAt(i+1);  
                string += String.fromCharCode(((c & 31) << 6) | (c2 & 63));  
                i += 2;  
            } else {  
                c2 = utftext.charCodeAt(i+1);  
                c3 = utftext.charCodeAt(i+2);  
                string += String.fromCharCode(((c & 15) << 12) | ((c2 & 63) << 6) | (c3 & 63));  
                i += 3;  
            }  
        }  
        return string;  
    }  
    
    
} 

function getCookie(cookieName) {
    var strCookie = document.cookie;
    var arrCookie = strCookie.split("; ");
    for(var i = 0; i < arrCookie.length; i++){
        var arr = arrCookie[i].split("=");
        if(cookieName == arr[0]){
            return arr[1];
        }
    }
    return "";
}