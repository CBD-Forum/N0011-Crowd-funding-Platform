$(function(){
//	bodyRSA();
//    var pp="singdd";
//    var Res = encryptedString(key, pp); 
	//加载初始页面
	$.ajax({
		type :'get',
		url :'http://localhost:8080/wwwAPI3.0/service/scoreService/getPageResult',
		data : {
			"pageNo":1,
			"pageSize":20
		},
		headers: {
//            "authorization":Res,
//            "key":key
        },
		dataType :'json',
		success : function(obj) {
			generateTable(obj);
		}
 	});
	
	$('#addBtn').bind('click',function(){
		add();
	});
	
	$('#batchDelBtn').bind('click',function(){
		batchDel();
	});
	
	$('#firstPage').bind('click',function(){
		firstPage();
	});
	
	$('#upPage').bind('click',function(){
		upPage();
	});
	
	$('#downPage').bind('click',function(){
		downPage();
	});
	
	$('#lastPage').bind('click',function(){
		lastPage();
	});
	
	$('#cancelBtn').bind('click',function(){
		var Idiv=document.getElementById("Idiv");
		Idiv.style.display="none";
		document.body.style.overflow = "auto"; //恢复页面滚动条
		var body = document.getElementsByTagName("body");
		var mybg = document.getElementById("mybg");
		body[0].removeChild(mybg);
	});
	
	$('#okBtn').bind('click',function(){
		submitRes($('#tip').html());
	});
	
	$('#batchAddBtn').bind('click',function(){
		$.ajax({
			type :'post',
			url :'http://localhost:8080/wwwAPI3.0/service/scoreService/batchAddScore',
			data : {
				"count":$('#addCountSel').val()
			},
			headers: {
	            "authorization":"singdd"
	        },
			dataType :'json',
			success : function(obj) {
				window.location.reload();
			}
	 	})
	});
})

function add(){
	$("#tip").html("新增页面");
	$('#id_type').val('');
	$('#up_date').val('');
	$('#id_no').val('');
	$('#sign_num').val('');
	$('#acct_scores').val('');
	openPage();
//	window.open("addandupdate/add",'_blank','height=600,width=800,top=0,left=0,toolbar=no,menubar=no,scrollbars=no, resizable=no,location=no, status=no');
}

function update(obj){
	$("#tip").html("修改页面");
	
	var type = "get";
	var requrl = "http://localhost:8080/wwwAPI3.0/service/scoreService/queryScore?id_no="+ obj;
	$.ajax({
		type : type,
		url :requrl,
		data : {
		},
		headers: {
            "authorization":"singdd"
        },
		dataType :'json',
		success : function(data) {
			$('#id_type').val(data.id_type);
			$('#up_date').val(data.up_date);
			$('#id_no').val(data.id_no);
			$('#sign_num').val(data.sign_num);
			$('#acct_scores').val(data.acct_scores);
		}
 	});
	openPage();
//	window.open("addandupdate/"+obj,'_blank','height=600,width=800,top=0,left=0,toolbar=no,menubar=no,scrollbars=no, resizable=no,location=no, status=no');
}

function del(obj){
	$.ajax({
		type :'delete',
		url :'http://localhost:8080/wwwAPI3.0/service/scoreService/deleteScore?id_no='+obj,
		data : {
		},
		headers: {
            "authorization":"singdd"
        },
		dataType :'json',
		success : function(data) {
			$('#tr-'+data.id).remove();
			window.location.reload();
		}
 	});
//	$('#'+obj).parent("td").parent("tr").remove();
}


function checkAll() {
	var code_Values = document.all['code_Value'];
	if (code_Values.length) {
		for (var i = 0; i < code_Values.length; i++) {
			code_Values[i].checked = true;
		}
	} else {
		code_Values.checked = true;
	}
	
	$("#ckb-").prop("checked",true);
	$("#ckb-").hide();
	$("#unckb").prop("checked",true);
	$("#unckb").show();
}

function uncheckAll() {
	var code_Values = document.all['code_Value'];
	if (code_Values.length) {
		for (var i = 0; i < code_Values.length; i++) {
			code_Values[i].checked = false;
		}
	} else {
		code_Values.checked = false;
	}
	
	$("#ckb-").prop("checked",false);
	$("#ckb-").show();
	$("#unckb").prop("checked",false);
	$("#unckb").hide();
}

function batchDel() {
	var num = 0;
	var code_Values = document.all['code_Value'];
	var ids = "";
	var id="";
	if (code_Values.length) {
		for (var i = 0; i < code_Values.length; i++) {
			if (code_Values[i].checked == true) {
				num++;
				ids += code_Values[i].id+",";
			}
		}
		ids = ids.substring(0, ids.length-1);
		ids = ids.replace(new RegExp("ckb-", 'g'), "");
		
		if($("#ckb-").attr("checked") == "checked"){
			ids = ids.substring(1, ids.length);
		}
	} else {
		if (code_Values.checked == true) {
			num++;
		}
	}
	if (num == 0) {
		alert('请选择要删除的项！');
		return;
	}
	if (num > 0) {
		$.ajax({
			type :'delete',
			url :'http://localhost:8080/wwwAPI3.0/service/scoreService/batchDelScore?id_no='+ids,
			data : {
			},
			headers: {
	            "authorization":"singdd"
	        },
			dataType :'json',
			success : function(data) {
				for(var i in data.ids){
					$('#tr-'+ data.ids[i]).remove();
				}
				window.location.reload();
			}
	 	});
	}
} 

var curPage = 1;
var maxPage = 0;
function firstPage(){
	curPage = 1;
	$.ajax({
		type :'get',
		url :'http://localhost:8080/wwwAPI3.0/service/scoreService/getPageResult',
		data : {
			"pageNo":1,
			"pageSize":20
		},
		headers: {
            "authorization":"singdd"
        },
		dataType :'json',
		success : function(data) {
			$("#service_tb").empty();
			j=0;
			generateTable(data);
		}
	});
}

function upPage(){
	if(curPage==1){
		return;
	}
	--curPage ;
	$.ajax({
		type :'get',
		url :'http://localhost:8080/wwwAPI3.0/service/scoreService/getPageResult',
		data : {
			"pageNo":curPage,
			"pageSize":20
		},
		headers: {
            "authorization":"singdd"
        },
		dataType :'json',
		success : function(data) {
			j = j-40;
			$("#service_tb").empty();
			generateTable(data);
		}
	})
}

function downPage(){
	$.ajax({
		type :'get',
		url :'http://localhost:8080/wwwAPI3.0/service/scoreService/getCountResult',
		data : {
		},
		headers: {
            "authorization":"singdd"
        },
		dataType :'json',
		success : function(data) {
			if(data.count%20==0){
				maxPage = data.count/20;
			}else{
				maxPage = Math.ceil(data.count/20)==0 ? 1:Math.ceil(data.count/20);
			}
			
			if(curPage==maxPage){
				return;
			}
			++curPage ;
			
			$.ajax({
				type :'get',
				url :'http://localhost:8080/wwwAPI3.0/service/scoreService/getPageResult',
				data : {
					"pageNo":curPage,
					"pageSize":20
				},
				headers: {
		            "authorization":"singdd"
		        },
				dataType :'json',
				success : function(data) {
					$("#service_tb").empty();
					generateTable(data);
				}
			});
		}
	});
}

function lastPage(){
	$.ajax({
		type :'get',
		url :'http://localhost:8080/wwwAPI3.0/service/scoreService/getCountResult',
		data : {
		},
		headers: {
            "authorization":"singdd"
        },
		dataType :'json',
		success : function(data) {
			if(data.count%20==0){
				maxPage = data.count/20;
			}else{
				maxPage = Math.ceil(data.count/20)==0 ? 1:Math.ceil(data.count/20);
			}
			curPage = maxPage;
			j = data.count-20;
			$.ajax({
				type :'get',
				url :'http://localhost:8080/wwwAPI3.0/service/scoreService/getPageResult',
				data : {
					"pageNo":maxPage,
					"pageSize":20,
				},
				headers: {
		            "authorization":"singdd"
		        },
				dataType :'json',
				success : function(data) {
					$("#service_tb").empty();
					generateTable(data);
				}
			})
		}
	})
}

var j=0;
function generateTable(obj){
	var rows = obj.data.length;
	$('#service_tb').append('<tr>'+
			'<td style="width:30px;color:orange;text-align: center;"><input type="checkbox" id="ckb-" onclick="checkAll();" name="code_Value"/><input type="checkbox" hidden="hidden" id="unckb" onclick="uncheckAll();" name="un_code_Value"/></td>'+
			'<td style="width:30px;color:orange;text-align: center;">'+"序号"+
			'</td><td style="width:60px;color:orange;text-align: center;">'+"类型"+
			'</td><td style="width:60px;color:orange;text-align: center;">'+"编号"+
			'</td><td style="width:60px;color:orange;text-align: center;">'+"积分"+
			'</td><td style="width:60px;color:orange;text-align: center;">'+"是否有效"+
			'</td><td style="width:60px;color:orange;text-align: center;">'+"更新时间"+
			'</td><td style="width:60px;color:orange;text-align: center;">'+"操作"+
			'</tr>');
	for(var i=0;i<rows;i++){
		j++;
		$('#service_tb').append('<tr id=tr-'+obj.data[i].id_no+'>' +
				'<td style="width:30px;color:orange;text-align: center;"><input type="checkbox" name="code_Value" id=ckb-'+obj.data[i].id_no+'></input></td>'+
				'<td style="width:30px;color:orange;text-align: center;">'+j+'</td>'+
				'<td style="width:60px;color:orange;text-align: center;" id='+obj.data[i].id_type+'>'+obj.data[i].id_type+'</td>'+
				'<td style="width:100px;color:orange;text-align: center;" id='+obj.data[i].id_no+'>'+obj.data[i].id_no+'</td>'+
				'<td style="width:100px;color:orange;text-align: center;" id='+obj.data[i].acct_scores+'>'+obj.data[i].acct_scores+'</td>'+
				'<td style="width:80px;color:orange;text-align: center;" id='+obj.data[i].sign_num+'>'+obj.data[i].sign_num+'</td>'+
				'<td style="width:100px;color:orange;text-align: center;" id='+obj.data[i].up_date+'>'+obj.data[i].up_date+'</td>'+
				'<td style="width:120px;color:orange;text-align: center;">'+
				'<a id='+obj.data[i].id_no+' href="javascript:void(0)" onclick="update(\''+obj.data[i].id_no+'\')">修改</a>&nbsp;&nbsp;&nbsp;'+
				'<a id='+obj.data[i].id_no+' href="javascript:void(0)" onclick="del(\''+obj.data[i].id_no+'\')">删除</a>'+
				'</td>'+
				'</tr>');
	}
}


function openPage(){
	//创建遮盖层
	var procbg = document.createElement("div"); 
	procbg.setAttribute("id","mybg"); 
	procbg.style.background = "#000000";
	procbg.style.width = "100%";
	procbg.style.height = "100%";
	procbg.style.position = "fixed";
	procbg.style.top = "0";
	procbg.style.left = "0";
	procbg.style.zIndex = "500";
	procbg.style.opacity = "0.3";
	procbg.style.filter = "Alpha(opacity=70)";
	//背景层加入页面
	document.body.appendChild(procbg);
	document.body.style.overflow = "hidden"; 
	
	//打开弹出层
	var Idiv     = document.getElementById("Idiv");
	var mou_head = document.getElementById('mou_head');
	Idiv.style.display = "block";
	//居中显示
	Idiv.style.left=(document.documentElement.clientWidth-Idiv.clientWidth)/2+document.documentElement.scrollLeft+"px";
	Idiv.style.top =(document.documentElement.clientHeight-Idiv.clientHeight)/2+document.documentElement.scrollTop+"px";
}

function submitRes(obj){
	var requrl = "";
	var type = "";
	if(obj=="新增页面"){
		$("#sign_num").removeAttr('disabled');
		type = "post";
		requrl = "http://localhost:8080/wwwAPI3.0/service/scoreService/addScore?id_no=add";
	}else{
		type = "put";
		requrl = "http://localhost:8080/wwwAPI3.0/service/scoreService/updateScore?id_no="+ $("#id_no").val();
	}
	
	var acct_scores = $('#acct_scores').val();
	var id_type = $('#id_type').val();
	if(acct_scores == ""){
		alert("积分不能为空！");
		return;
	}
	if(id_type == ""){
		alert("类型不能为空！");
		return;
	}
	
	$.ajax({
		type : type,
		url :requrl,
		data : {
			"acct_scores" :$('#acct_scores').val(),
			"id_type" :$('#id_type').val(),
		},
		headers: {
            "authorization":"singdd"
        },
		dataType :'json',
		success : function(data) {
//			opener.location.reload();
			window.location.reload();
			window.close();
		}
 	})
}

var key ;   
function bodyRSA(){   
    setMaxDigits(130);   
    key = new RSAKeyPair("10001","","91257035a847c620fdb2e92fdfeccb39255234f5d7882e8bc99063b8849e3213c0a5f686480e4c157d6bccc17cd8920364a473747517b3c008b434a3319a684975f3667c63fb951c194ad00e3d1e89e0cc17c58f74562e7207a2c32952a7f85f353103ec6ed5ba87785084b694b368ebca6d1a42537bee16231893c159534eaf");    
}
