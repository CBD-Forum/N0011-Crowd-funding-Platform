$(function(){
	var user_session_id = getCookie("user_session_id");
	var user_session_name = getCookie("user_session_name");
	if(user_session_id!=null && user_session_id!=''){
		$(".login").html(user_session_name);
		$("#logout").show();
	}else{
		$(".login").html("登录");
		$("#logout").hide();
	}
	
	var b = new Base64(); 
	var userlistparam = '["query","userList","fZeF4V4KQzk5qi2yRr79NNoJ0VbIEs52"]';
    var userliststr = b.encode(userlistparam);
    
    $.ajax({
		type :'get',
		url :url+'?username=sam&orgName=org1&peer=peer1&args='+userliststr+'&chaincodeVersion=v0',
		data : {
		},
		dataType :'json',
		success : function(data) {
			for(var k=0;k<data.length;k++){
				if(data[k].name==user_session_name){
					var orderlistparam = '["query","orderList","'+data[k].id+'"]';
					var orderliststr = b.encode(orderlistparam);
					$.ajax({
						type :'get',
						url :url+'?username=sam&orgName=org1&peer=peer1&args='+orderliststr+'&chaincodeVersion=v0',
						data : {
						},
						dataType :'json',
						success : function(obj) {
							if(obj!=null){
								for(var i=0;i<obj.length;i++){
									var id = obj[i].id;
									var amount = obj[i].amount;//总金额
									var current = obj[i].current;//已筹款
									var progress = (current/amount)*100 + '%';//进度
									var investcount = obj[i].investRecords.length
									
									$("#index_ul").append("<li id='"+id+"'><a href='order/"+id+"'><img src='images/example"+i+".jpg'><dl><dt><h3>山禽之王——珍珠鸡</h3><p>珍珠鸡又称珠鸡、山鸡，珍珠鸡头很小，面部淡青紫色，后部红色，在喙的后下方左右各有一个心状肉垂，全身羽毛灰色，并有规则的圆形白点，形如珍珠，故有“珍珠鸡”之美称。</p></dt><dd><p>农产品</p><div class='progress'><div class='progress-bar' role='progressbar' aria-valuenow='60' aria-valuemin='0' aria-valuemax='100' style='width: "+progress+";'></div></div><div class='row'><div class='col-md-4'><span>￥"+current+"</span><br />已筹款 </div><div class='col-md-4'>"+investcount+"<br />支持数 </div><div class='col-md-4'>"+progress+"<br />筹款进度 </div></div></dd></dl></a></li>");
								}
							}
						}
				 	})
				 	
				 	break;
				}
			}
			
		}
 	})
	
//	var orderlist = '[{"id": "PHc3dz1eYvd5c67rx6E264z78kv82z7V","title": "众筹_1","amount": 10000,"current": 8000,"status": 4,"rate": 0.05999999865889549,"createTime": "2017-05-11 00:00:00","creatorId": "o28PAHPV43niKttV7hOKG1XBds4Sste7","endTime": "2017-06-11 23:59:59","investRecords":[{"id": "5Uq0w36NpXd731UO2n5u7Q3WKTTqX02k","creatorId": "Jd6cBgryga3mB9gkb5xNp1H6NP226P6h", "orderId": "30c5TPro230L2l8l77q2bOX3heL3592C","amount": 1000 },{"id": "6HvxzK1E374W12Uirs5vL1A25q0FCcbJ","creatorId": "Jd6cBgryga3mB9gkb5xNp1H6NP226P6h","orderId": "30c5TPro230L2l8l77q2bOX3heL3592C","amount": 9000}],"refundRecords": [{"id": "41rXrq971b57OJ4klcRHjouWY8A1uimZ","creatorId": "Jd6cBgryga3mB9gkb5xNp1H6NP226P6h","orderId": "30c5TPro230L2l8l77q2bOX3heL3592C","amount": 1000 },{"id": "7fdk405KxIG9EpFPO5D3Be35ZV7s1uI2","creatorId": "Jd6cBgryga3mB9gkb5xNp1H6NP226P6h","orderId": "30c5TPro230L2l8l77q2bOX3heL3592C","amount": 9000}]}]';
		
	$("#submitBtn").click(function(){
		var index = layer.load(1, {
        	shade: [0.6,'#fff'] //0.1透明度的白色背景
    	});
		$.ajax({
			type :'get',
			url :url+'?username=sam&orgName=org1&peer=peer1&args='+userliststr+'&chaincodeVersion=v0',
			data : {
			},
			dataType :'json',
			success : function(data) {
				var username = $("#username").val();
				$(".login").html($("#username").val());
				$("#login-form").hide();
				
				for(var k=0;k<data.length;k++){
					if(data[k].name==username){
						document.cookie="user_session_id="+data[k].id;
						document.cookie="user_session_name="+username;
						break;
					}
				}
				location.reload();
			}
		})
		
	})
	
	$("#logout").click(function(){
		DelCookie("user_session_id");
		DelCookie("user_session_name");
		
		window.location.href="/fcwallet";
	})
})

function Base64() {  
	   
    // private property  
    _keyStr = "ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789+/=";  
   
    // public method for encoding  
    this.encode = function (input) {  
        var output = "";  
        var chr1, chr2, chr3, enc1, enc2, enc3, enc4;  
        var i = 0;  
        input = _utf8_encode(input);  
        while (i < input.length) {  
            chr1 = input.charCodeAt(i++);  
            chr2 = input.charCodeAt(i++);  
            chr3 = input.charCodeAt(i++);  
            enc1 = chr1 >> 2;  
            enc2 = ((chr1 & 3) << 4) | (chr2 >> 4);  
            enc3 = ((chr2 & 15) << 2) | (chr3 >> 6);  
            enc4 = chr3 & 63;  
            if (isNaN(chr2)) {  
                enc3 = enc4 = 64;  
            } else if (isNaN(chr3)) {  
                enc4 = 64;  
            }  
            output = output +  
            _keyStr.charAt(enc1) + _keyStr.charAt(enc2) +  
            _keyStr.charAt(enc3) + _keyStr.charAt(enc4);  
        }  
        return output;  
    }  
   
    // public method for decoding  
    this.decode = function (input) {  
        var output = "";  
        var chr1, chr2, chr3;  
        var enc1, enc2, enc3, enc4;  
        var i = 0;  
        input = input.replace(/[^A-Za-z0-9\+\/\=]/g, "");  
        while (i < input.length) {  
            enc1 = _keyStr.indexOf(input.charAt(i++));  
            enc2 = _keyStr.indexOf(input.charAt(i++));  
            enc3 = _keyStr.indexOf(input.charAt(i++));  
            enc4 = _keyStr.indexOf(input.charAt(i++));  
            chr1 = (enc1 << 2) | (enc2 >> 4);  
            chr2 = ((enc2 & 15) << 4) | (enc3 >> 2);  
            chr3 = ((enc3 & 3) << 6) | enc4;  
            output = output + String.fromCharCode(chr1);  
            if (enc3 != 64) {  
                output = output + String.fromCharCode(chr2);  
            }  
            if (enc4 != 64) {  
                output = output + String.fromCharCode(chr3);  
            }  
        }  
        output = _utf8_decode(output);  
        return output;  
    }  
   
    // private method for UTF-8 encoding  
    _utf8_encode = function (string) {  
        string = string.replace(/\r\n/g,"\n");  
        var utftext = "";  
        for (var n = 0; n < string.length; n++) {  
            var c = string.charCodeAt(n);  
            if (c < 128) {  
                utftext += String.fromCharCode(c);  
            } else if((c > 127) && (c < 2048)) {  
                utftext += String.fromCharCode((c >> 6) | 192);  
                utftext += String.fromCharCode((c & 63) | 128);  
            } else {  
                utftext += String.fromCharCode((c >> 12) | 224);  
                utftext += String.fromCharCode(((c >> 6) & 63) | 128);  
                utftext += String.fromCharCode((c & 63) | 128);  
            }  
   
        }  
        return utftext;  
    }  
   
    // private method for UTF-8 decoding  
    _utf8_decode = function (utftext) {  
        var string = "";  
        var i = 0;  
        var c = c1 = c2 = 0;  
        while ( i < utftext.length ) {  
            c = utftext.charCodeAt(i);  
            if (c < 128) {  
                string += String.fromCharCode(c);  
                i++;  
            } else if((c > 191) && (c < 224)) {  
                c2 = utftext.charCodeAt(i+1);  
                string += String.fromCharCode(((c & 31) << 6) | (c2 & 63));  
                i += 2;  
            } else {  
                c2 = utftext.charCodeAt(i+1);  
                c3 = utftext.charCodeAt(i+2);  
                string += String.fromCharCode(((c & 15) << 12) | ((c2 & 63) << 6) | (c3 & 63));  
                i += 3;  
            }  
        }  
        return string;  
    }  
} 

function getCookie(cookieName) {
    var strCookie = document.cookie;
    var arrCookie = strCookie.split("; ");
    for(var i = 0; i < arrCookie.length; i++){
        var arr = arrCookie[i].split("=");
        if(cookieName == arr[0]){
            return arr[1];
        }
    }
    return "";
}

function DelCookie(name) {
	  var exp = new Date();
	  exp.setTime(exp.getTime() + (-1 * 24 * 60 * 60 * 1000));
	  var cval = GetCookieValue(name);
	  document.cookie = name + "=" + cval + "; expires=" + exp.toGMTString();
}

function GetCookieValue(name) {
	  var cookieValue = null;
	  if (document.cookie && document.cookie != '') {
	 var cookies = document.cookie.split(';');
	 for (var i = 0; i < cookies.length; i++) {
	   var cookie = jQuery.trim(cookies[i]);
	   //PYYH=USERNAME=steven&PASSWORD=111111&UserID=1&UserType=1
	   if (cookie.substring(0, name.length + 1) == (name + '=')) {
	 cookieValue = decodeURIComponent(cookie.substring(name.length + 1));
	 //USERNAME=steven&PASSWORD=111111&UserID=1&UserType=1
	 break;
	   }
	 }
	  }
	  return cookieValue;
	}
