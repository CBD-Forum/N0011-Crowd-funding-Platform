$(function(){
	var user_session_id = getCookie("user_session_id");
	var user_session_name = getCookie("user_session_name");
	if(user_session_id!=null && user_session_id!=''){
		$(".login").html(user_session_name);
		$("#logout").show();
	}else{
		$(".login").html("登录");
		$("#logout").hide();
	}
	var b = new Base64();  
	var orderId = window.location.pathname.substr("/fcwallet/order/".length);
    var param = '["query","order","'+orderId+'"]';
    var str = b.encode(param);
	$.ajax({
		type :'get',
		url :url+'?username=sam&orgName=org1&peer=peer1&args='+str+'&chaincodeVersion=v0',
		data : {
		},
		dataType :'json',
		success : function(obj) {
				var id = obj.id;
				orderId = id;
				var amount = obj.amount;//总金额
				var current = obj.current;//已筹款
				var progress = ((current/amount)*100).toFixed(2) + '%';//进度
				var investcount = obj.investRecords.length;
				var rate = obj.rate*100;//收益率
				var title = obj.title;
				var createTime = obj.createTime;//创建时间
				var creatorId = obj.creatorId;//创建人id
				var endTime = obj.endTime;//结束时间
				var syTime = dumpTime(new Date(createTime),new Date(endTime));//剩余时间
				var status = obj.status;//状态
				if(status=="0"){
					$("#order_details").append("<table><thead><td>参考回报率</td><td>目标金额（元）</td><td>期限（月）</td><td>认筹单位（元/份）</td></thead><tbody><td>"+(rate).toFixed(2)+"%</td><td>"+amount+"</td><td>12</td><td>1</td></tbody></table><div class='progress-box'><div class='pull-left'>进度 : <span>"+progress+"</span></div><div class='cf-progress pull-right'><div class='cf-progress-bar' style='width:"+progress+"'></div></div></div><ul class='info'><li class='pull-left'><p>回报方式：固定收益</p><p>上线时间："+createTime+"</p><p>剩余时间：<span>"+syTime+"</span></p></li><li class='pull-right'><p>最小认筹：1份</p><p>最大认筹："+amount+"份</p><p>剩余份数："+amount+"份</p></li></ul><button id='join-btn-fb'>发布</button>");
				}else if(status=="1"){
					$("#order_details").append("<table><thead><td>参考回报率</td><td>目标金额（元）</td><td>期限（月）</td><td>认筹单位（元/份）</td></thead><tbody><td>"+(rate).toFixed(2)+"%</td><td>"+amount+"</td><td>12</td><td>1</td></tbody></table><div class='progress-box'><div class='pull-left'>进度 : <span>"+progress+"</span></div><div class='cf-progress pull-right'><div class='cf-progress-bar' style='width:"+progress+"'></div></div></div><ul class='info'><li class='pull-left'><p>回报方式：固定收益</p><p>上线时间："+createTime+"</p><p>剩余时间：<span>"+syTime+"</span></p></li><li class='pull-right'><p>最小认筹：1份</p><p>最大认筹："+amount+"份</p><p>剩余份数："+(amount-current)+"份</p></li></ul><button id='join-btn'>认筹</button>");
				}else if(status=="2"){
					progress ="100%"
					$("#order_details").append("<table><thead><td>参考回报率</td><td>目标金额（元）</td><td>期限（月）</td><td>认筹单位（元/份）</td></thead><tbody><td>"+(rate).toFixed(2)+"%</td><td>"+amount+"</td><td>12</td><td>1</td></tbody></table><div class='progress-box'><div class='pull-left'>进度 : <span>"+progress+"</span></div><div class='cf-progress pull-right'><div class='cf-progress-bar' style='width:"+progress+"'></div></div></div><ul class='info'><li class='pull-left'><p>回报方式：固定收益</p><p>上线时间："+createTime+"</p><p>剩余时间：<span>"+syTime+"</span></p></li><li class='pull-right'><p>最小认筹：1份</p><p>最大认筹："+amount+"份</p><p>剩余份数："+(amount-current)+"份</p></li></ul><button id='join-btn-full'>放款</button>");
				}else{
					progress ="100%"
					$("#order_details").append("<table><thead><td>参考回报率</td><td>目标金额（元）</td><td>期限（月）</td><td>认筹单位（元/份）</td></thead><tbody><td>"+(rate).toFixed(2)+"%</td><td>"+amount+"</td><td>12</td><td>1</td></tbody></table><div class='progress-box'><div class='pull-left'>进度 : <span>"+progress+"</span></div><div class='cf-progress pull-right'><div class='cf-progress-bar' style='width:"+progress+"'></div></div></div><ul class='info'><li class='pull-left'><p>回报方式：固定收益</p><p>上线时间："+createTime+"</p><p>剩余时间：<span>"+syTime+"</span></p></li><li class='pull-right'><p>最小认筹：1份</p><p>最大认筹："+amount+"份</p><p>剩余份数："+0+"份</p></li></ul>");
					$("#join-btn").attr({disabled:"disabled",stype:"background: gray !important"});
				}
				
				var userlistparam = '["query","userList","fZeF4V4KQzk5qi2yRr79NNoJ0VbIEs52"]';
			    var userliststr = b.encode(userlistparam);
			    
			    $.ajax({
					type :'get',
					url :url+'?username=sam&orgName=org1&peer=peer1&args='+userliststr+'&chaincodeVersion=v0',
					data : {
					},
					dataType :'json',
					success : function(data) {
						for(var k=0;k<data.length;k++){
							if(data[k].id==creatorId){
								$("#order_title").html(title+"<br /><span>发起人</span><b>"+data[k].name+"</b><a href='#'>联系我</a>");
								break;
							}
						}
					}
			    })
				
				
				$("#join-btn").on("click", function() {
					$("#order_ky_account").html("您的账户可用余额："+(amount-current)+" 元");
					$("#rcname").html(title);
					$("#mbje").html("目标金额："+amount + " 元");
					$("#yrcrs").html("已认筹人数：" +investcount);
					$("#ratep").html((rate).toFixed(2));
			        $("#join-box").show();
			    })
			    $("#join-close").on("click", function() {
			        $("#join-box").hide();
			    })
			    //投资
			    $("#join-submit").on("click", function(e) {
			        e.preventDefault();
			        var index = layer.load(1, {
			        	shade: [0.6,'#fff'] //0.1透明度的白色背景
		        	});
			    	var tz_param = '["invest",'+'"'+orderId+'","'+user_session_id+'",'+'"'+$("#tzmoney").val()+'"]';
				    var tz_str = b.encode(tz_param);
					$.ajax({
						type :'post',
						url :url,
						data : {
							"peers": ["localhost:7051"],
							"chaincodeVersion":"v0",
							"functionName":"invoke",
							"username":"sam",
					        "orgName":"org1",
						    "args":tz_str
						},
						dataType :'text',
						success : function(obj) {
//							console.info(obj);
							if(obj!=null || obj!=""){
								 $("#join-box").hide();
								 location.reload();
							}
						}
				 	})
			    })
			    $(".cancel-submit").on("click", function() {
			        $("#confirm-box").hide();
			    })
			    $(".tabs").on("click", "li", function() {
			        var index = $(this).index();
			        switch(index){
			            case 3:
			                $('html,body').animate({scrollTop:$(".records").offset().top - 72}, 500);
			                break;
			        }
			    })
			    //发布
			    $("#join-btn-fb").click(function(){
			    	var index = layer.load(1, {
			        	shade: [0.6,'#fff'] //0.1透明度的白色背景
		        	});
					var fb_param = '["publish",'+'"'+orderId+'"]';
				    var fb_str = b.encode(fb_param);
					$.ajax({
						type :'post',
						url :url,
						data : {
							"peers": ["localhost:7051"],
							"chaincodeVersion":"v0",
							"functionName":"invoke",
							"username":"sam",
					        "orgName":"org1",
						    "args":fb_str
						},
						dataType :'json',
						success : function(obj) {
						}
				 	})
				 	setTimeout(function(){
						location.reload();
					},10000)
				})
				
				//放款
			    $("#join-btn-full").click(function(){
			    	var index = layer.load(1, {
			        	shade: [0.6,'#fff'] //0.1透明度的白色背景
		        	});
					var fk_param = '["loan",'+'"'+orderId+'"]';
				    var fk_str = b.encode(fk_param);
					$.ajax({
						type :'post',
						url :url,
						data : {
							"peers": ["localhost:7051"],
							"chaincodeVersion":"v0",
							"functionName":"invoke",
							"username":"sam",
					        "orgName":"org1",
						    "args":fk_str
						},
						dataType :'json',
						success : function(obj) {
						}
				 	})
				 	setTimeout(function(){
						location.reload();
					},10000)
				})
				
				
		}
 	})
	
})

function dumpTime(date1,date2){
    var date3 = date2.getTime() - new Date(date1).getTime();   //时间差的毫秒数        
    //计算出相差天数  
    var days=Math.floor(date3/(24*3600*1000))  
  
    //计算出小时数  
  
    var leave1=date3%(24*3600*1000)    //计算天数后剩余的毫秒数  
    var hours=Math.floor(leave1/(3600*1000))  
    //计算相差分钟数  
    var leave2=leave1%(3600*1000)        //计算小时数后剩余的毫秒数  
    var minutes=Math.floor(leave2/(60*1000))  
    //计算相差秒数  
    var leave3=leave2%(60*1000)      //计算分钟数后剩余的毫秒数  
    var seconds=Math.round(leave3/1000)  
    return days+"天 "+hours+"小时 "+minutes+" 分钟"+seconds+" 秒"; 
}

function Base64() {  
	   
    // private property  
    _keyStr = "ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789+/=";  
   
    // public method for encoding  
    this.encode = function (input) {  
        var output = "";  
        var chr1, chr2, chr3, enc1, enc2, enc3, enc4;  
        var i = 0;  
        input = _utf8_encode(input);  
        while (i < input.length) {  
            chr1 = input.charCodeAt(i++);  
            chr2 = input.charCodeAt(i++);  
            chr3 = input.charCodeAt(i++);  
            enc1 = chr1 >> 2;  
            enc2 = ((chr1 & 3) << 4) | (chr2 >> 4);  
            enc3 = ((chr2 & 15) << 2) | (chr3 >> 6);  
            enc4 = chr3 & 63;  
            if (isNaN(chr2)) {  
                enc3 = enc4 = 64;  
            } else if (isNaN(chr3)) {  
                enc4 = 64;  
            }  
            output = output +  
            _keyStr.charAt(enc1) + _keyStr.charAt(enc2) +  
            _keyStr.charAt(enc3) + _keyStr.charAt(enc4);  
        }  
        return output;  
    }  
   
    // public method for decoding  
    this.decode = function (input) {  
        var output = "";  
        var chr1, chr2, chr3;  
        var enc1, enc2, enc3, enc4;  
        var i = 0;  
        input = input.replace(/[^A-Za-z0-9\+\/\=]/g, "");  
        while (i < input.length) {  
            enc1 = _keyStr.indexOf(input.charAt(i++));  
            enc2 = _keyStr.indexOf(input.charAt(i++));  
            enc3 = _keyStr.indexOf(input.charAt(i++));  
            enc4 = _keyStr.indexOf(input.charAt(i++));  
            chr1 = (enc1 << 2) | (enc2 >> 4);  
            chr2 = ((enc2 & 15) << 4) | (enc3 >> 2);  
            chr3 = ((enc3 & 3) << 6) | enc4;  
            output = output + String.fromCharCode(chr1);  
            if (enc3 != 64) {  
                output = output + String.fromCharCode(chr2);  
            }  
            if (enc4 != 64) {  
                output = output + String.fromCharCode(chr3);  
            }  
        }  
        output = _utf8_decode(output);  
        return output;  
    }  
   
    // private method for UTF-8 encoding  
    _utf8_encode = function (string) {  
        string = string.replace(/\r\n/g,"\n");  
        var utftext = "";  
        for (var n = 0; n < string.length; n++) {  
            var c = string.charCodeAt(n);  
            if (c < 128) {  
                utftext += String.fromCharCode(c);  
            } else if((c > 127) && (c < 2048)) {  
                utftext += String.fromCharCode((c >> 6) | 192);  
                utftext += String.fromCharCode((c & 63) | 128);  
            } else {  
                utftext += String.fromCharCode((c >> 12) | 224);  
                utftext += String.fromCharCode(((c >> 6) & 63) | 128);  
                utftext += String.fromCharCode((c & 63) | 128);  
            }  
   
        }  
        return utftext;  
    }  
   
    // private method for UTF-8 decoding  
    _utf8_decode = function (utftext) {  
        var string = "";  
        var i = 0;  
        var c = c1 = c2 = 0;  
        while ( i < utftext.length ) {  
            c = utftext.charCodeAt(i);  
            if (c < 128) {  
                string += String.fromCharCode(c);  
                i++;  
            } else if((c > 191) && (c < 224)) {  
                c2 = utftext.charCodeAt(i+1);  
                string += String.fromCharCode(((c & 31) << 6) | (c2 & 63));  
                i += 2;  
            } else {  
                c2 = utftext.charCodeAt(i+1);  
                c3 = utftext.charCodeAt(i+2);  
                string += String.fromCharCode(((c & 15) << 12) | ((c2 & 63) << 6) | (c3 & 63));  
                i += 3;  
            }  
        }  
        return string;  
    }  
} 

function getCookie(cookieName) {
    var strCookie = document.cookie;
    var arrCookie = strCookie.split("; ");
    for(var i = 0; i < arrCookie.length; i++){
        var arr = arrCookie[i].split("=");
        if(cookieName == arr[0]){
            return arr[1];
        }
    }
    return "";
}



